# FusionSOC–NIST

Extend FusionSOC with **NIST SP 800-53 Rev.5** and **NIST CSF** mappings.

## Structure
- kql
- detections
- controls
- evidence
- workbooks
- playbooks
- policies
- docs

**Updated:** 2025-08-10
