# AC-7 – Unsuccessful Logon Attempts
Intent, Implementation, Detection, Test Story, Evidence.
