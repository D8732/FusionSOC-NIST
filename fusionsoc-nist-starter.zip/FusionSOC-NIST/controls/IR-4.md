# IR-4 – Incident Handling
Intent, Implementation, Detection, Test Story, Evidence.
