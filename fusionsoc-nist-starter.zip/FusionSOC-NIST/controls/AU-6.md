# AU-6 – Audit Review
Intent, Implementation, Detection, Test Story, Evidence.
